pushd frontend
npm i && npm run build
popd