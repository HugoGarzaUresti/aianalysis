export { default } from "./TermsAndConditions";
