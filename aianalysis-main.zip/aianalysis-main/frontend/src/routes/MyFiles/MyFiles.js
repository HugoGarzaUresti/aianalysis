import FileList from "../../components/FileList";

function MyFiles() {
  return (
    <>
      <FileList />
    </>
  );
}

export default MyFiles;
