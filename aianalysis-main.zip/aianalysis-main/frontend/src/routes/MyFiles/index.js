export { default } from "./MyFiles";
