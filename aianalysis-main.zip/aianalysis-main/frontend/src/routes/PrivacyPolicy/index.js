export { default } from "./PrivacyPolicy";
