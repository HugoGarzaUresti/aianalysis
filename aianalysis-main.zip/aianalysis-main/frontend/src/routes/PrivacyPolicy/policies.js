export const policies = [
  {
    id: crypto.randomUUID(),
    policy: "This website does not collect any personal information.",
  },
  {
    id: crypto.randomUUID(),
    policy: "This website does not use cookies.",
  },
  {
    id: crypto.randomUUID(),
    policy: "This website does not use any third-party services.",
  },
];
