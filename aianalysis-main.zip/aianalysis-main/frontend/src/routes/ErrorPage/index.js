export { default } from "./ErrorPage";
