import fileDefault from "../assets/file-blank-solid-240.png";

export const imageConfig = {
  default: fileDefault,
};
