export { default } from "./GlobalStyles";
