export { default } from "./InputForm";
